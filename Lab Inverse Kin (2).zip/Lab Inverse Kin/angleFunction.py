from serial import Serial

ser = Serial('COM9', 115200, timeout=1) #Remember to change COM number
print( ser.readline().decode('utf-8').strip() ) #Should say 'hi.'
