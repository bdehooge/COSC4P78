from serial import Serial
import math
import queue
import time

innerArmLength = 8
outerArmLength = 8
shoulderAngleMin = 50
shoulderAngleMax = 210
elbowAngleMin = 50
elbowAngleMax = 225
servoMin = 75
servoMaxShoulder = 444
servoMaxElbow = 470

def main():

    penState = 2 #1 for up, 2 for down?

    ser = Serial('COM9', 115200, timeout=1) #Remember to change COM number
    print( ser.readline().decode('utf-8').strip() ) #Should say 'hi.'

    q = queue.Queue()
    print("Please enter coordinates in the form x,y ie: 100,100 . To change pen state type 'pen'. Enter 'quit' to exit: ")
    
    #Input Loop
    while True:
        inpString = input("Enter Coordinates: ")
        if inpString == "quit":
            break
        inpList = inpString.split(",")
        if inpList[0] == "pen":
            q.put("pen")
        else:
            x, y = inpList[0], inpList[1]
            q.put((int(x), int(y)))
    
    print("Coordinates entered. Press Enter to begin.")
    input()
    
    #Running Loop
    while q.qsize() > 0:
        command = q.get()
        if command == "pen":
            penState = 2 if penState == 1 else 1
            print("Pen state changed to: ", penState)
            continue
        else:
            x, y = command
            shoulderMotorAngle, elbowMotorAngle = getAngles(x, y)
            shoulderMotorAngle, elbowMotorAngle = round(shoulderMotorAngle), round(elbowMotorAngle)
            shoulderPulse = angleToPulse(shoulderMotorAngle, shoulderAngleMin, shoulderAngleMax, servoMin, servoMaxShoulder)
            elbowPulse = angleToPulse(elbowMotorAngle, elbowAngleMin, elbowAngleMax, servoMin, servoMaxElbow)
            writeAngles(ser, shoulderPulse, elbowPulse, penState)
            time.sleep(1)
    print("Job done!")

def getAngles(x, y):
    hypotenuse = math.sqrt(x**2 + y**2)
    hypotenuseAngle = math.asin(x/hypotenuse)
    innerAngle = math.acos((hypotenuse**2 + innerArmLength**2 - outerArmLength**2)/(2*hypotenuse*innerArmLength))
    shoulderMotorAngle = hypotenuseAngle - innerAngle
    outerAngle = math.acos((innerArmLength**2 + outerArmLength**2 - hypotenuse**2)/(2*innerArmLength*outerArmLength))
    elbowMotorAngle = math.pi - outerAngle
    print("shoulderMotorAngle: ", math.degrees(shoulderMotorAngle), "elbowMotorAngle: ", math.degrees(elbowMotorAngle))
    return (math.degrees(shoulderMotorAngle)*-1+50, math.degrees(elbowMotorAngle))    

def writeAngles(ser, shoulderPulse, elbowPulse, penState):
    angleString = "{%d,%d,%d}\n" % (shoulderPulse, elbowPulse, penState)
    print(angleString)
    angleString = angleString.encode()
    ser.write(angleString)
    
def angleToPulse(angle_deg, min_angle_deg, max_angle_deg, servo_min_pulse, servo_max_pulse):
    # 1) Clamp angle
    clamped_angle = max(min_angle_deg, min(angle_deg, max_angle_deg))
    # 2) Scale to [servo_min_pulse, servo_max_pulse]
    scale = (servo_max_pulse - servo_min_pulse) / (max_angle_deg - min_angle_deg)
    pulse = servo_min_pulse + (clamped_angle - min_angle_deg) * scale
    return int(pulse)


if __name__ == "__main__":
    main()